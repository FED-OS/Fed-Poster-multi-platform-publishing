<!--
  Thank you for contributing to Fed-Poster! 🎉
  Please fill out the sections below. The more detail you give, the faster we can review.
  See CONTRIBUTING.md for our process. Be kind, follow the Code of Conduct.
-->

## 📌 Description

<!-- What does this PR do, and why? Link the issue: "Closes #123" -->

Closes #

## 🧩 Type of Change

- [ ] 🐛 Bug fix (non-breaking)
- [ ] ✨ New feature (non-breaking)
- [ ] 💥 Breaking change (fix or feature that would cause existing behavior to change)
- [ ] 📝 Documentation update
- [ ] 🎨 UI/UX / styling
- [ ] 🔌 New platform integration (see ADR-0007)
- [ ] ♻️ Refactor (no functional change)
- [ ] ⚡ Performance improvement
- [ ] ✅ Test addition/improvement
- [ ] 🔒 Security-related (please request a security review)
- [ ] 🏗️ Chores / deps / CI

## 🎯 Scope

<!-- Briefly describe what files/areas this touches and why. -->

## 🧪 Testing

- [ ] I ran `npm run lint` locally and it passes
- [ ] I ran `npm test` locally and it passes
- [ ] I ran `npm run build` locally and it passes
- [ ] I added/updated tests for the new behavior
- [ ] I manually verified the change in the browser/app

### How to test

<!-- Steps a reviewer can follow to verify this change. -->

## 📸 Screenshots / Recordings

<!-- For UI changes, add before/after screenshots or a short recording. -->

## 📝 Documentation

- [ ] Updated [README.md](../README.md) if needed
- [ ] Updated [usage.md](../usage.md) if needed
- [ ] Updated the [Wiki](https://github.com/FED-OS/Fed-Poster/wiki) if needed
- [ ] Added a [CHANGELOG.md](../CHANGELOG.md) entry under `[Unreleased]`
- [ ] Added an [ADR.md](../ADR.md) entry if architecturally significant

## 🔒 Security Checklist

- [ ] No secrets, tokens, or `.env` files committed
- [ ] No user passwords stored (OAuth tokens / app passwords only)
- [ ] No new network calls over HTTP (HTTPS only)
- [ ] No `eval` or `innerHTML` with untrusted input
- [ ] No security headers / CSP weakened

## ✅ Conventions

- [ ] Commits follow [Conventional Commits](https://www.conventionalcommits.org/)
- [ ] Branch is named per convention (`feature/`, `fix/`, `docs/`, etc.)
- [ ] CSS uses theme variables (no hardcoded colors)
- [ ] PR is focused — one concern per PR

## 💬 Notes for Reviewers

<!-- Anything reviewers should pay extra attention to, tricky parts, or open questions. -->

---

<div align="center">
  <sub>💙 Thanks for making Fed-Poster better!</sub>
</div>
