---
name: ✨ Feature Request
about: Suggest a new feature or improvement
title: "[FEATURE] <short description>"
labels: ["enhancement", "needs triage"]
assignees: []
projects: []
---

## ✨ Feature Summary

<!-- A clear, concise description of the feature you'd like. -->

## 🎯 The Problem

<!-- What problem does this solve? What's the use case?
     Describe the *why*, not just the *what*. -->

## 💡 Proposed Solution

<!-- How you imagine it working. UI sketches, API shape, or just a description. -->

## 🔄 Alternatives Considered

<!-- Any other ways to solve this, and why they're less ideal. -->

## 🧩 Additional Context

<!-- Screenshots, links to other tools that do this, related issues/discussions, mockups. -->

## 📊 Impact & Priority

- **Who benefits:** <!-- e.g. all users, agency tier, self-hosters, developers -->
- **How often:** <!-- daily / weekly / occasionally -->
- **Priority (your view):** <!-- low / medium / high -->

## ✅ Checklist

- [ ] I searched existing issues, Discussions, and the Roadmap for duplicates
- [ ] I described the problem, not just the solution
- [ ] This fits Fed-Poster's scope (a multi-channel *publisher*, local-first, OAuth-only)

<!--
  🙏 Thanks! Feature requests are reviewed during roadmap planning.
  Want it sooner? Consider contributing it — see CONTRIBUTING.md and ADR-0007.
-->
