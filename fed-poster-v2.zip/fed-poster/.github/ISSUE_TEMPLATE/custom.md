---
name: 📝 Custom Issue
about: Something that isn't a bug or feature request (question, task, refactor, etc.)
title: "<short description>"
labels: ["needs triage"]
assignees: []
projects: []
---

## 📝 Summary

<!-- A clear, concise description of the issue or task. -->

## 🧩 Type

- [ ] ❓ Question / discussion (consider Discussions instead)
- [ ] 🏗️ Task / chore
- [ ] ♻️ Refactor
- [ ] 📚 Documentation
- [ ] 🔌 Platform integration proposal (see ADR-0007)
- [ ] 🧪 Testing / CI
- [ ] 🎨 Design / branding
- [ ] Other: <!-- specify -->

## 📋 Details

<!-- Explain what's needed, why, and any constraints. -->

## ✅ Acceptance Criteria

<!-- What does "done" look like? -->
- [ ]
- [ ]
- [ ]

## 🔗 Related

<!-- Links to issues, PRs, Discussions, ADRs, or external references. -->

## 📸 Additional Context

<!-- Anything else helpful. ⚠️ Never paste tokens/secrets. -->

<!--
  🐛 Bug? Use the Bug Report template.
  ✨ Feature? Use the Feature Request template.
  🔒 Security? Do NOT open an issue — see SECURITY.md.
-->
