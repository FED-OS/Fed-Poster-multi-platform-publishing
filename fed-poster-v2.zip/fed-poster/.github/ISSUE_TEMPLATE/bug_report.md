---
name: 🐛 Bug Report
about: Something isn't working as expected — report it here
title: "[BUG] <short description>"
labels: ["bug", "needs triage"]
assignees: []
projects: []
---

## 🐛 Bug Description

<!-- A clear, concise description of what the bug is. -->

## 🔁 Steps to Reproduce

1.
2.
3.

## ✅ Expected Behavior

<!-- What you expected to happen. -->

## ❌ Actual Behavior

<!-- What actually happened. -->

## 📸 Screenshots / Recordings

<!-- If applicable, add screenshots or a screen recording to help explain. -->

## 🖥️ Environment

- **Fed-Poster version:** <!-- e.g. 2.0.0, or "latest main" -->
- **How you run it:** <!-- Hosted / self-hosted / Docker / local file -->
- **Browser & version:** <!-- e.g. Chrome 126 -->
- **OS:** <!-- e.g. macOS 14, Windows 11, Ubuntu 24.04 -->
- **Affected platform(s):** <!-- e.g. Telegram, Bluesky, Zapier, all -->

## 🔧 Additional Context

<!-- Logs, console errors, network responses, or anything else relevant.
     ⚠️ NEVER paste tokens, passwords, or `.env` contents here. -->

## ✅ Checklist

- [ ] I searched existing issues and Discussions for duplicates
- [ ] I can reproduce this consistently
- [ ] I'm using a supported version (see SECURITY.md)
- [ ] I did NOT include any secrets/tokens

<!--
  🔒 Security issue? Do NOT use this template.
  See SECURITY.md and open a private security advisory instead.
-->
