# 💬 Welcome to Fed-Poster Discussions!

<div align="center">
  <img src="https://img.shields.io/badge/Discussions-open-purple?style=for-the-badge" alt="Discussions" />
  <img src="https://img.shields.io/badge/community-friendly-brightgreen?style=for-the-badge" alt="Friendly" />
</div>

Hey, and welcome! 👋 Thanks for stopping by the Fed-Poster community. This is the place to ask questions, share ideas, show off what you built, and help shape the future of open-source multi-channel publishing.

---

## 🗂️ Categories

| Category        | Use it for                                            |
|-----------------|-------------------------------------------------------|
| 🙋 **Q&A**       | Questions with a definitive answer (best for support) |
| 💡 **Ideas**      | Proposals, brainstorming, feature suggestions         |
| 📣 **Announcements** | News from maintainers (releases, changes)         |
| 🙌 **Show and tell** | Share projects, integrations, workflows you built |
| ☕ **General**    | Anything else that's community-related                |

> 💡 **Bug reports and feature requests should still go to [Issues](https://github.com/FED-OS/Fed-Poster/issues).** Discussions is for conversation; Issues is for actionable, trackable work.

---

## ✨ Getting Started

1. **Introduce yourself** in General — we'd love to know how you use Fed-Poster.
2. **Search first** — your question or idea may already be answered.
3. **Pick the right category** so the right people see it.
4. **Be specific** — include context, what you tried, and what you're trying to achieve.

---

## 📜 Ground Rules

- 💙 **Be kind and respectful.** This space is governed by our [Code of Conduct](../CODE_OF_CONDUCT.md). Harassment, spam, and disrespect are not tolerated.
- 🎯 **Stay on topic.** Keep posts relevant to Fed-Poster and multi-channel publishing.
- 🔒 **No secrets.** Never paste tokens, passwords, or `.env` contents. See [SECURITY.md](../SECURITY.md).
- 🐛 **Bugs → Issues.** Discussions aren't tracked for fixes.
- 🤝 **Help others.** If you know the answer, jump in — community support keeps the project healthy.

---

## 🆘 Need Help Fast?

- 🐛 Bug? → [Open an issue](https://github.com/FED-OS/Fed-Poster/issues/new/choose)
- 🔒 Security? → See [SECURITY.md](../SECURITY.md) (**do not** post publicly)
- 📖 Docs → [README](../README.md) · [usage.md](../usage.md) · [Wiki](https://github.com/FED-OS/Fed-Poster/wiki)
- 🏢 Commercial/enterprise → business@fedpromptly.com

---

## 🏆 Become a Regular

- Answer questions in Q&A — consistent helpers earn the **Triager** role (see [GOVERNANCE.md](../GOVERNANCE.md)).
- Share your integrations in **Show and tell**.
- Propose ideas in **Ideas** — good ones get added to the [Roadmap](../ROADMAP.md).
- Contribute code — see [CONTRIBUTING.md](../CONTRIBUTING.md).

---

<div align="center">
  <sub>💬 <strong>Pull up a chair. You belong here.</strong></sub>
</div>
