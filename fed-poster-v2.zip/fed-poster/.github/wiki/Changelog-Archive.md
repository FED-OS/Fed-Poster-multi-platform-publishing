# 📜 Changelog Archive

Older release notes live in [CHANGELOG.md](https://github.com/FED-OS/Fed-Poster/blob/main/CHANGELOG.md). This page links to notable release summaries and migration notes.

## Major releases
- **v2.0.0** — redesigned dashboard, 20 direct + 450+ Zapier, analytics, self-host. (See CHANGELOG.md)
- **v1.4.0** — DeviantArt, SafeW, WordPress Jetpack.
- **v1.3.0** — Buffer proxy, Tumblr, draft auto-save.
- **v1.2.0** — GitHub Gist/Repo, file attachments.
- **v1.1.0** — Discord, Mastodon, HTTPS enforcement.
- **v1.0.0** — initial public release (Telegram, Bluesky).

## Migration notes
- **0.x → 1.x:** re-add credentials (storage keys changed).
- **1.x → 2.0:** credentials migrate automatically; review new pricing/limits.

➡️ Full history: [CHANGELOG.md](https://github.com/FED-OS/Fed-Poster/blob/main/CHANGELOG.md).
