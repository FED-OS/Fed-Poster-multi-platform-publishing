# 🤝 Contributor Guide (Wiki)

This wiki page is a companion to [CONTRIBUTING.md](https://github.com/FED-OS/Fed-Poster/blob/main/CONTRIBUTING.md). Read that first — this page adds community tips.

## Good first contributions
- 🐛 Triage issues: reproduce bugs, label them, link duplicates.
- 📝 Improve docs/wiki (typo fixes welcome).
- 🎨 Polish `styles.css` using theme variables.
- 🔌 Add a platform adapter (ADR-0007).
- 🧪 Add tests for untested adapters.

## Tips
- Keep PRs small and focused.
- Reference ADRs when your change relates to architecture.
- Run `npm run lint && npm test && npm run build` before pushing.
- Use Conventional Commits.
- Be responsive to review feedback.

## Roles
See [GOVERNANCE.md](https://github.com/FED-OS/Fed-Poster/blob/main/GOVERNANCE.md): Contributor → Triager → Maintainer → Core Team.

➡️ Start with [`good first issue`](https://github.com/FED-OS/Fed-Poster/labels/good%20first%20issue) labels.
