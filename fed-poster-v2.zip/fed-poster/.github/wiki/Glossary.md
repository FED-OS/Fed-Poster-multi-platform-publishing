# 📖 Glossary

Terms used across Fed-Poster docs.

| Term | Meaning |
|------|---------|
| **Direct integration** | Fed-Poster calls the platform's API directly from the browser |
| **Proxy** | A bridge service (Buffer, WordPress Jetpack) forwards posts to platforms |
| **OAuth** | Authorization standard; users grant scoped access without sharing passwords |
| **App password** | Platform-generated scoped password (Bluesky, GitHub PAT, etc.) |
| **PAT** | Personal Access Token (GitHub) |
| **Webhook** | A URL that receives POST payloads (Discord, Zapier) |
| **`localStorage`** | Browser key-value store where Fed-Poster keeps scoped credentials |
| **IndexedDB** | Browser DB used for drafts |
| **Edge Function** | Supabase serverless function used as a stateless OAuth proxy |
| **Zapier** | Automation service extending reach to 450+ platforms |
| **Adapter** | A platform integration module (see ADR-0007) |
| **Feature flag** | Toggle to roll out a feature safely |
| **ADR** | Architecture Decision Record (see ADR.md) |
| **SemVer** | Semantic Versioning (MAJOR.MINOR.PATCH) |
| **Delivery** | One post to one platform (pricing unit) |
| **Self-host** | Run Fed-Poster on your own infrastructure |
| **CSP** | Content Security Policy (security header) |
| **Federation / ActivityPub** | Decentralized social protocol (planned for v3.0) |

➡️ Missing a term? Add it via a PR or suggest it in Discussions.
