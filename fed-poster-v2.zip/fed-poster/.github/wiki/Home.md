# 📚 Fed-Poster Wiki — Home

> Welcome to the Fed-Poster wiki! This is the community-maintained knowledge base. The canonical docs live in the repository (README, usage.md, ADR.md, etc.); this wiki extends them with guides, how-tos, and community knowledge.
>
> 📌 **For official docs**, start at the [README](https://github.com/FED-OS/Fed-Poster#readme). **For support**, see [SUPPORT.md](https://github.com/FED-OS/Fed-Poster/blob/main/SUPPORT.md).

---

## 🗺️ Wiki Pages

| Page | Description |
|------|-------------|
| [Home](./Home) | This page — start here |
| [Getting-Started](./Getting-Started) | Install, connect your first platform, send your first post |
| [Platform-Guides](./Platform-Guides) | Per-platform setup (Telegram, Bluesky, Mastodon, Discord, GitHub, …) |
| [Zapier-Extension](./Zapier-Extension) | Reach 450+ platforms via Zapier |
| [Self-Hosting](./Self-Hosting) | Run Fed-Poster on your own infrastructure |
| [Security-Hardening](./Security-Hardening) | Production hardening checklist (extends SECURITY.md) |
| [Theming](./Theming) | Customize colors and layout via `styles.css` variables |
| [Troubleshooting](./Troubleshooting) | Common issues and fixes |
| [FAQ](./FAQ) | Frequently asked questions |
| [Glossary](./Glossary) | Terms used in Fed-Poster |
| [Contributor-Guide](./Contributor-Guide) | Wiki companion to CONTRIBUTING.md |
| [Changelog-Archive](./Changelog-Archive) | Older release notes |

---

## 🚀 Quick Links

- 🏠 [Repository](https://github.com/FED-OS/Fed-Poster)
- 📖 [usage.md](https://github.com/FED-OS/Fed-Poster/blob/main/usage.md)
- 🗺️ [Roadmap](https://github.com/FED-OS/Fed-Poster/blob/main/ROADMAP.md)
- 🏗️ [Architecture Decisions (ADRs)](https://github.com/FED-OS/Fed-Poster/blob/main/ADR.md)
- 🚀 [Deployment Guide](https://github.com/FED-OS/Fed-Poster/blob/main/DEPLOYMENT.md)
- 💬 [Discussions](https://github.com/FED-OS/Fed-Poster/discussions)
- 🐛 [Issues](https://github.com/FED-OS/Fed-Poster/issues)

---

## ✏️ Editing the Wiki

This wiki is open to contributors with write access. To suggest a change:

1. Open a [Discussion](https://github.com/FED-OS/Fed-Poster/discussions) with your proposed edit, **or**
2. If you have wiki write access, edit the page directly using the GitHub wiki UI.

Please keep wiki content consistent with the repo docs. If a wiki page contradicts the repo, **the repo wins** — open a PR to fix the repo, then update the wiki.

---

## 📜 License & Conduct

Wiki content is licensed under the project's [MIT License](https://github.com/FED-OS/Fed-Poster/blob/main/LICENSE). Participation is governed by the [Code of Conduct](https://github.com/FED-OS/Fed-Poster/blob/main/CODE_OF_CONDUCT.md).

---

<div align="center">
  <sub>📚 <strong>The wiki is a garden — tend it kindly.</strong></sub>
</div>
