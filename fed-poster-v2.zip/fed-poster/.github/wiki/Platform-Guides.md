# 🔌 Platform Guides

Per-platform setup notes. For the general flow, see [usage.md](https://github.com/FED-OS/Fed-Poster/blob/main/usage.md) and [Getting Started](./Getting-Started).

## Telegram
- **Need:** Bot token (from @BotFather) + chat/channel ID.
- **Media:** photos, videos.
- **Limits:** 4096 chars/message.
- **Tip:** To post to a channel, add the bot as admin with "Post Messages" permission.

## Bluesky
- **Need:** handle + app password (Settings → App passwords).
- **Media:** up to 4 images.
- **Limits:** 300 chars; uses AT Protocol.
- **Tip:** App passwords are scoped — safer than your main password.

## Mastodon
- **Need:** instance URL + access token (instance → Preferences → Development → New Application, scopes: `write:media write:statuses`).
- **Media:** images, videos, audio.
- **Limits:** default 500 chars (instance-configurable).

## Discord
- **Need:** incoming webhook URL (Channel → Integrations → Webhooks).
- **Media:** attachments via webhook.
- **Limits:** 2000 chars/message.
- **Tip:** Use separate webhooks per channel.

## GitHub (Gist)
- **Need:** Personal Access Token with `gist` scope.
- **Use:** publish a post as a gist.

## GitHub (Repo)
- **Need:** PAT with `repo` scope (or fine-grained `contents:write`).
- **Use:** push a file to a repo.

## Tumblr / SafeW / DeviantArt (OAuth)
- **Need:** Supabase Edge Functions deployed (see [Self-Hosting](./Self-Hosting)).
- **Flow:** click **Connect** → OAuth → token stored locally.

## Buffer / WordPress Jetpack (Proxy)
- **Need:** proxy account credentials.
- **Reach:** Twitter/X, LinkedIn, Facebook, Instagram, Tumblr via the proxy.

## Zapier (450+)
See [Zapier Extension](./Zapier-Extension).

---

➡️ Want a platform not listed? See [ADR-0007](https://github.com/FED-OS/Fed-Poster/blob/main/ADR.md#adr-0007-adding-a-new-platform-adapter) and open a feature request.
