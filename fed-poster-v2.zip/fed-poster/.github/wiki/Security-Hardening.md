# 🔐 Security Hardening

Extends [SECURITY.md](https://github.com/FED-OS/Fed-Poster/blob/main/SECURITY.md) with practical, copy-paste-ready hardening for self-hosters.

## HTTPS
- Use Caddy (auto-HTTPS) or Nginx + Let's Encrypt/certbot.
- Redirect all HTTP → HTTPS.

## Headers (Nginx)
```nginx
add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
add_header X-Content-Type-Options "nosniff" always;
add_header X-Frame-Options "DENY" always;
add_header Referrer-Policy "no-referrer" always;
add_header Permissions-Policy "geolocation=(), microphone=(), camera=()" always;
add_header Content-Security-Policy "default-src 'self'; img-src 'self' data: https:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdnjs.cloudflare.com; font-src 'self' https://fonts.gstatic.com; script-src 'self'; connect-src 'self' https://api.telegram.org https://bsky.social https://*.supabase.co; frame-ancestors 'none'" always;
```

## Headers (Caddy)
```caddyfile
header {
    Strict-Transport-Security "max-age=31536000; includeSubDomains"
    X-Content-Type-Options nosniff
    X-Frame-Options DENY
    Referrer-Policy no-referrer
    Permissions-Policy "geolocation=(), microphone=(), camera=()"
    Content-Security-Policy "default-src 'self'; ..."
}
```

## Supabase
- Restrict Edge Function origins to your domain.
- Rotate the anon key if exposed (it's public-safe but good hygiene).
- Keep server-only secrets in Supabase, never in the repo.

## Dependencies
- Dependabot is enabled (see [`.github/dependabot.yml`](https://github.com/FED-OS/Fed-Poster/blob/main/.github/dependabot.yml)).
- Review and merge dependency PRs promptly.
- Run `npm audit` regularly.

## Credential hygiene
- Tell users to use app passwords / scoped tokens, never main passwords.
- Warn against using Fed-Poster on shared computers.
- Document token rotation.

➡️ See [SECURITY.md](https://github.com/FED-OS/Fed-Poster/blob/main/SECURITY.md) for the full policy and reporting process.
