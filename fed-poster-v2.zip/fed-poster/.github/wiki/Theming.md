# 🎨 Theming

Fed-Poster styles live in [`styles.css`](https://github.com/FED-OS/Fed-Poster/blob/main/styles.css). Theming is driven by **CSS custom properties** in `:root`. Change them once; the whole UI updates.

## Current palette
```css
:root {
  --bg-body: #07090f;
  --bg-surface: #0e111c;
  --bg-card: #161b2b;
  --bg-card-hover: #1e2438;
  --text-primary: #edf0fa;
  --text-secondary: #8890b0;
  --text-muted: #6b7280;
  --accent: #7c5cfc;
  --accent-2: #5b8def;
  --gradient-main: linear-gradient(135deg, #7c5cfc, #5b8def, #f472b6);
  --gradient-gold: linear-gradient(135deg, #f59e0b, #fbbf24);
  --gradient-red: linear-gradient(135deg, #ef4444, #dc2626);
  --radius: 20px;
  --radius-sm: 12px;
  --shadow: 0 20px 60px rgba(0, 0, 0, 0.6);
  --transition: 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}
```

## Light theme (coming soon — see Roadmap)
A light theme is planned via a `[data-theme="light"]` selector overriding the same variables. When implementing, **don't hardcode colors** — add the override variables and toggle the attribute.

## Customizing
1. Edit the variables above in your fork's `styles.css`.
2. (Optional) add a `[data-theme="..."]` block to support multiple themes.
3. Keep the social-preview prompts in sync if you change the palette (see [`assets/social-preview/README.md`](https://github.com/FED-OS/Fed-Poster/blob/main/assets/social-preview/README.md)).

## Rules
- **Never hardcode hex colors** in components — always use a variable.
- Add new colors as variables in `:root` so they're themeable.

➡️ See [ADR-0008](https://github.com/FED-OS/Fed-Poster/blob/main/ADR.md#adr-0008-extract-css-into-stylescss).
