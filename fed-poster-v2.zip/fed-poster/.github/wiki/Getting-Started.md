# 🚀 Getting Started

New to Fed-Poster? This guide gets you from zero to your first multi-platform post in minutes.

> Need to *install/deploy* first? See [Self-Hosting](./Self-Hosting) and [DEPLOYMENT.md](https://github.com/FED-OS/Fed-Poster/blob/main/DEPLOYMENT.md).

## 1. Open the dashboard
Use the hosted version or your self-hosted instance.

## 2. Connect your first platform
Pick the easiest platform to start:

### Telegram (quickest)
1. Message [@BotFather](https://t.me/BotFather) → `/newbot` → get the **bot token**.
2. Add the bot to your channel/group (or get your chat ID).
3. In Fed-Poster's Telegram tab, paste the token + chat ID → **Save** → **Test**.

### Bluesky
1. Go to Bluesky **Settings → App passwords** → create one.
2. In the Bluesky tab, enter handle + app password → **Save** → **Test**.

### Discord
1. In your server: **Channel Settings → Integrations → Webhooks → New Webhook** → copy URL.
2. In the Discord tab, paste the webhook URL → **Save** → **Test**.

## 3. Compose a post
1. Open **Multi-Platform Post**.
2. Select your connected platform(s).
3. Write a message.
4. (Optional) attach media.
5. Review the per-platform preview.
6. Click **Publish**.

## 4. Schedule & analyze
- Toggle **Schedule** to pick a time.
- Check the **Delivery** view for status and errors.

---

➡️ Next: [Platform Guides](./Platform-Guides) · [Troubleshooting](./Troubleshooting) · [usage.md](https://github.com/FED-OS/Fed-Poster/blob/main/usage.md)
