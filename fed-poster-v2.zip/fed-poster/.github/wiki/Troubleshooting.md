# 🧯 Troubleshooting

Common issues and fixes. For more, see [SUPPORT.md](https://github.com/FED-OS/Fed-Poster/blob/main/SUPPORT.md).

| Symptom | Likely cause | Fix |
|---------|--------------|-----|
| Blank page after deploy | Non-relative paths | Ensure `styles.css` is referenced relatively; build output serves from root |
| Styles missing | `styles.css` not deployed | Confirm the file is in the served directory |
| Telegram: 401 Unauthorized | Bad bot token / chat ID | Re-create token via @BotFather; confirm chat ID |
| Bluesky: invalid password | Used main password | Use an **app password** (Settings → App passwords) |
| Mastodon: 403 | Wrong scopes | App needs `write:statuses write:media` |
| Discord: no message | Wrong webhook URL / channel | Recreate webhook; ensure channel allows it |
| GitHub: 403 | PAT scope too narrow | Use `gist` (Gist) or `repo`/`contents:write` (Repo) |
| OAuth (Tumblr/SafeW/DeviantArt) 401 | Edge function misconfigured | Check Supabase secrets + function URL in `.env` |
| Tokens not persisting | Private mode / localStorage disabled | Use normal browsing; check browser settings |
| Mixed-content warnings | HTTP asset on HTTPS page | Serve everything over HTTPS |
| CORS error on direct API | Platform blocks browser calls | Use the proxy/edge function for that platform |
| Zapier not firing | Wrong webhook URL / Zap paused | Verify URL; ensure Zap is on; check Zapier task limit |
| Schedule didn't post | Browser was closed (client-only) | Keep app open, or use the self-hosted worker (Roadmap) |

## Debug tips
- Open DevTools → Console & Network tabs.
- Reproduce with **Test** button first (safe ping).
- Check the platform panel's status badge.
- Export delivery logs (CSV/JSON) for failed posts.

➡️ Still stuck? Open a [Discussion](https://github.com/FED-OS/Fed-Poster/discussions) (questions) or a [bug report](https://github.com/FED-OS/Fed-Poster/issues/new?template=bug_report.md). Security issues → [SECURITY.md](https://github.com/FED-OS/Fed-Poster/blob/main/SECURITY.md).
