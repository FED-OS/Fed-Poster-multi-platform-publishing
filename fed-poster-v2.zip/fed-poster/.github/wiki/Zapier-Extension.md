# ⚡ Zapier Extension

Fed-Poster reaches **450+ platforms** via Zapier. You bring your own Zapier account.

## Setup
1. In Zapier, create a **Zap** with **Trigger → Webhooks by Zapier → Catch Hook**. Copy the webhook URL.
2. In Fed-Poster, open the **Zapier** panel and add the webhook URL.
3. Configure the Zap's **Action** (e.g., post to Pinterest, create a Twitch clip, send to a niche platform).
4. When you publish with Zapier selected, Fed-Poster sends your post payload to the webhook.

## Payload shape (example)
```json
{
  "text": "Hello world!",
  "media": ["https://.../image.png"],
  "platforms": ["zapier"],
  "scheduledAt": null
}
```

## Notes
- Each Zap run may consume **one or more Zapier tasks** — manage your Zapier plan.
- You can map multiple Zaps (one webhook per destination) and select them per post.
- Fed-Poster sends the payload; Zapier handles the destination platform's auth.

## Limitations
- Zapier task limits apply.
- Real-time delivery depends on Zapier's polling/trigger speed.
- For high-volume posting, prefer direct integrations where available.

➡️ See [usage.md](https://github.com/FED-OS/Fed-Poster/blob/main/usage.md#-zapier-extension-450-platforms) and [ADR-0006](https://github.com/FED-OS/Fed-Poster/blob/main/ADR.md#adr-0006-extend-reach-via-zapier-instead-of-bespoke-adapters).
