# ❓ FAQ

Expanded FAQ. Also see [usage.md FAQ](https://github.com/FED-OS/Fed-Poster/blob/main/usage.md#-faq-usage) and [PRICING.md FAQ](https://github.com/FED-OS/Fed-Poster/blob/main/PRICING.md).

## General
**Is Fed-Poster free?**
The open-source core is free under MIT. Hosted/managed plans add analytics & support (see PRICING.md).

**Is my data sold?**
Never. See SECURITY.md.

**Can I self-host?**
Yes — see [Self-Hosting](./Self-Hosting) and DEPLOYMENT.md.

## Security
**Where are my credentials stored?**
In your browser's `localStorage`, scoped per platform. OAuth tokens / app passwords only.

**Do you store my passwords?**
No. Never use your main password — use tokens/app passwords.

**Can I use it on a shared computer?**
Not recommended. If you must, clear browser data after use.

## Platforms
**How many platforms?**
~20 direct + 450+ via Zapier.

**Can I add a platform?**
Yes — see [ADR-0007](https://github.com/FED-OS/Fed-Poster/blob/main/ADR.md#adr-0007-adding-a-new-platform-adapter).

**Why Zapier?**
Reaching hundreds of niche platforms without per-adapter maintenance. See [ADR-0006](https://github.com/FED-OS/Fed-Poster/blob/main/ADR.md#adr-0006-extend-reach-via-zapier-instead-of-bespoke-adapters).

## Scheduling
**Does it post when my browser is closed?**
Client-only mode: no. An always-on scheduler is on the Roadmap; the self-hosted worker enables it today.

➡️ More questions? Ask in [Discussions](https://github.com/FED-OS/Fed-Poster/discussions).
