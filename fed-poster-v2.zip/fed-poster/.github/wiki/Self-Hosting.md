# 🏠 Self-Hosting

Fed-Poster is a **static front-end** (HTML + CSS + JS) with optional **Supabase Edge Functions** for OAuth. You can host it almost anywhere. For the full guide, see [DEPLOYMENT.md](https://github.com/FED-OS/Fed-Poster/blob/main/DEPLOYMENT.md).

## Quick options
- **GitHub Pages:** Settings → Pages → `main` / root. Free, zero-config.
- **Cloudflare Pages:** connect Git, output dir = root. Free + fast CDN.
- **Netlify / Vercel:** import repo, no build, publish dir = `.`. Preview deploys per PR.
- **Docker:** `docker-compose up -d` → `http://localhost:8080`.
- **Nginx / Caddy:** serve the folder; Caddy gives auto-HTTPS.

## Enabling OAuth (Tumblr / SafeW / DeviantArt)
1. Create a Supabase project.
2. Add platform OAuth client secrets to Edge Function secrets (not in the repo).
3. Deploy the functions from `supabase/functions/`.
4. Set `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` in `.env`.

## Must-do hardening
- Serve over HTTPS.
- Set CSP + security headers.
- Keep `.env` out of git.
- Keep deps updated (Dependabot is on by default).

➡️ Full details: [DEPLOYMENT.md](https://github.com/FED-OS/Fed-Poster/blob/main/DEPLOYMENT.md) · [Security Hardening](./Security-Hardening) · [SECURITY.md](https://github.com/FED-OS/Fed-Poster/blob/main/SECURITY.md)
